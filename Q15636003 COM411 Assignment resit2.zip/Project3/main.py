"""
This module is responsible for the overall program flow. It controls how the user interacts with the
program and how the program behaves. It uses the other modules to interact with the user, carry out
processing, and for visualising information.

Note:   any user input/output should be done in the module 'tui'
        any processing should be done in the module 'process'
        any visualisation should be done in the module 'visual'
"""
from process import (
    read_data_from_csv,
    get_reviews_by_park,
    count_reviews_by_park_and_location,
    get_average_rating_by_park_and_year,
    count_reviews_by_park,
    get_average_scores_by_park,
    get_top_locations_by_park,
    get_monthly_average_ratings,
    count_reviews_by_park_and_location,
    get_average_rating_by_park_and_year,
    get_average_score_by_park_and_location,
    Exporter
)
from tui import display_header, display_menu, display_submenu_a, display_submenu_b, display_export_menu
from visual import plot_pie_chart, plot_bar_chart, plot_top_locations_chart, plot_monthly_average_ratings

def main():
    display_header("Disneyland Review Analyzer")
    data = read_data_from_csv('data/disneyland_reviews.csv')
    
    def process_submenu_a(sub_choice):
        if sub_choice == 'A':
            park_name = input("Please provide the park name to retrieve reviews: ")
            reviews = get_reviews_by_park(data, park_name)
            if reviews:
                print(f"Total {len(reviews)} reviews found for {park_name}:")
                for review in reviews:
                    print(review)
            else:
                print("Sorry, no reviews are available for the specified park.")
        elif sub_choice == 'B':
            park_name = input("Please provide the park name to count reviews by location: ")
            location = input("Please provide the reviewer's location: ")
            count = count_reviews_by_park_and_location(data, park_name, location)
            print(f"The park '{park_name}' has {count} reviews from '{location}'.")
        elif sub_choice == 'C':
            park_name = input("Please provide the park name to check average rating by year: ")
            year = int(input("Please provide the year: "))
            average_rating = get_average_rating_by_park_and_year(data, park_name, year)
            if average_rating is not None:
                print(f"The average rating for {park_name} in {year} is {average_rating:.2f}.")
            else:
                print(f"Sorry, no reviews are available for {park_name} in {year}.")
        elif sub_choice == 'D':
            average_scores = get_average_score_by_park_and_location(data)
            for park, locations in average_scores.items():
                print(f"\nPark: {park}")
                for location, average in locations.items():
                    print(f"  Location: {location}, Average Score: {average:.2f}")

    def process_submenu_b(sub_choice):
        if sub_choice == 'A':
            review_counts = count_reviews_by_park(data)
            plot_pie_chart(review_counts)
        elif sub_choice == 'B':
            average_scores = get_average_scores_by_park(data)
            plot_bar_chart(average_scores, "Average Review Scores per Park", "Parks", "Average Score")
        elif sub_choice == 'C':
            park_name = input("Please provide the park name to see top locations by rating: ")
            top_locations = get_top_locations_by_park(data, park_name)
            plot_top_locations_chart(top_locations)
        elif sub_choice == 'D':
            park_name = input("Please provide the park name to see average rating per month: ")
            monthly_average_ratings = get_monthly_average_ratings(data, park_name)
            plot_monthly_average_ratings(monthly_average_ratings)

    def process_export(export_choice):
        exporter = Exporter(data)
        filename = input("Please provide the filename to save the export (without extension): ")
        if export_choice == '1':
            exporter.export_to_txt(f"{filename}.txt")
            print(f"Data has been successfully exported to {filename}.txt")
        elif export_choice == '2':
            exporter.export_to_csv(f"{filename}.csv")
            print(f"Data has been successfully exported to {filename}.csv")
        elif export_choice == '3':
            exporter.export_to_json(f"{filename}.json")
            print(f"Data has been successfully exported to {filename}.json")

    while True:
        choice = display_menu()
        if choice == 'X':
            print("Thank you for using the program. Goodbye!")
            break
        elif choice == 'A':
            sub_choice = display_submenu_a()
            process_submenu_a(sub_choice)
        elif choice == 'B':
            sub_choice = display_submenu_b()
            process_submenu_b(sub_choice)
        elif choice == 'C':
            export_choice = display_export_menu()
            process_export(export_choice)

if __name__ == "__main__":
    main()
