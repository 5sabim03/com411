"""
This module is responsible for visualising the data using Matplotlib.
Any visualisations should be generated via functions in this module.
"""
import matplotlib.pyplot as plt


def plot_bar_chart(data, title, xlabel, ylabel):
    labels, values = list(data.keys()), list(data.values())
    plt.figure(figsize=(10, 6))
    plt.bar(labels, values)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.show()


def plot_pie_chart(data):
    labels, sizes = list(data.keys()), list(data.values())
    plt.figure(figsize=(10, 6))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    plt.title('Number of Reviews per Park')
    plt.show()


def plot_monthly_average_ratings(data):
    months, ratings = list(data.keys()), list(data.values())
    plt.figure(figsize=(10, 6))
    plt.bar(months, ratings)
    plt.xlabel('Month')
    plt.ylabel('Average Rating')
    plt.title('Average Rating per Month')
    plt.show()


def plot_top_locations_chart(data):
    locations, averages = zip(*data)
    locations, averages = list(locations), list(averages)
    plt.figure(figsize=(10, 6))
    plt.bar(locations, averages)
    plt.xlabel('Locations')
    plt.ylabel('Average Rating')
    plt.title('Top 10 Locations with Highest Average Rating')
    plt.show()
