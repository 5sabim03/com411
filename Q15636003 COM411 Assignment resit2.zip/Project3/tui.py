"""
TUI is short for Text-User Interface. This module is responsible for communicating with the user.
The functions in this module will display information to the user and/or retrieve a response from the user.
Each function in this module should utilise any parameters and perform user input/output.
A function may also need to format and/or structure a response e.g. return a list, tuple, etc.
Any errors or invalid inputs should be handled appropriately.
Please note that you do not need to read the data file or perform any other such processing in this module.
"""
def display_header(title):
    line = '-' * len(title)
    print(f"{line}\n{title}\n{line}")


def display_menu():
    menu_text = """
Please enter the letter which corresponds with your desired menu choice:
[A] View Data
[B] Visualise Data
[C] Export Data
[X] Exit
"""
    print(menu_text)
    choice = input("Your choice: ").strip().upper()
    while choice not in {'A', 'B', 'C', 'X'}:
        choice = input("Invalid input. Please enter A, B, C or X.\nYour choice: ").strip().upper()

    choices = {
        'A': "You have chosen option A - View Data",
        'B': "You have chosen option B - Visualise Data",
        'C': "You have chosen option C - Export Data",
        'X': "You have chosen to Exit"
    }
    print(choices[choice])
    return choice


def display_submenu_a():
    submenu_text = """
Please enter one of the following options:
[A] View Reviews by Park
[B] Number of Reviews by Park and Reviewer Location
[C] Average Score per year by Park
[D] Average Score per Park by Reviewer Location
"""
    print(submenu_text)
    choice = input("Your choice: ").strip().upper()
    while choice not in {'A', 'B', 'C', 'D'}:
        choice = input("Invalid input. Please enter A, B, C, or D.\nYour choice: ").strip().upper()
    return choice


def display_submenu_b():
    submenu_text = """
Please enter one of the following options:
[A] Most Reviewed Parks
[B] Average Scores
[C] Park Ranking by Nationality
[D] Most Popular Month by Park
"""
    print(submenu_text)
    choice = input("Your choice: ").strip().upper()
    while choice not in {'A', 'B', 'C', 'D'}:
        choice = input("Invalid input. Please enter A, B, C, or D.\nYour choice: ").strip().upper()
    return choice


def display_export_menu():
    export_text = """
Please choose an export format:
[1] TXT
[2] CSV
[3] JSON
"""
    print(export_text)
    choice = input("Your choice: ").strip()
    while choice not in {'1', '2', '3'}:
        choice = input("Invalid input. Please enter 1, 2, or 3.\nYour choice: ").strip()
    return choice