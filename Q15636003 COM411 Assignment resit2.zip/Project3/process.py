"""
This module is responsible for processing the data.  It will largely contain functions that will recieve the overall dataset and 
perfrom necessary processes in order to provide the desired result in the desired format.
It is likely that most sections will require functions to be placed in this module.
"""
import json
import csv

def read_data_from_csv(file_path):
    try:
        with open(file_path, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            data = list(reader)
            print(f"Data has been successfully loaded. Number of rows: {len(data)}")
            return data
    except FileNotFoundError:
        print("File not found. Please check the path and try again.")
        return []

def aggregate_data(data):
    review_counts = {}
    park_ratings = {}
    location_ratings = {}
    monthly_ratings = {}

    for review in data:
        park = review['Branch']
        location = review['Reviewer_Location']
        rating = int(review['Rating'])
        year_month = review['Year_Month']

        # Count reviews by park
        review_counts[park] = review_counts.get(park, 0) + 1

        # Average scores by park
        park_ratings.setdefault(park, []).append(rating)

        # Top locations by park
        if park not in location_ratings:
            location_ratings[park] = {}
        location_ratings[park].setdefault(location, []).append(rating)

        # Monthly average ratings by park
        if park not in monthly_ratings:
            monthly_ratings[park] = {}
        month = year_month[5:7]
        monthly_ratings[park].setdefault(month, []).append(rating)

    average_scores_by_park = {park: sum(ratings) / len(ratings) for park, ratings in park_ratings.items()}
    top_locations_by_park = {park: sorted(
        {location: sum(ratings) / len(ratings) for location, ratings in locations.items()}.items(),
        key=lambda x: x[1], reverse=True)[:10] for park, locations in location_ratings.items()}
    monthly_average_ratings = {park: {month: sum(ratings) / len(ratings) for month, ratings in months.items()}
                               for park, months in monthly_ratings.items()}

    return review_counts, average_scores_by_park, top_locations_by_park, monthly_average_ratings

def get_reviews_by_park(data, park_name):
    return [review for review in data if review['Branch'] == park_name]

def count_reviews_by_park_and_location(data, park_name, location):
    return sum(1 for review in data if review['Branch'] == park_name and review['Reviewer_Location'] == location)

def get_average_rating_by_park_and_year(data, park_name, year):
    reviews = [int(review['Rating']) for review in data if review['Branch'] == park_name and review['Year_Month'].startswith(str(year))]
    return sum(reviews) / len(reviews) if reviews else None

def get_average_score_by_park_and_location(data):
    location_scores = {}
    for review in data:
        park = review['Branch']
        location = review['Reviewer_Location']
        rating = int(review['Rating'])
        location_scores.setdefault(park, {}).setdefault(location, []).append(rating)
    return {park: {location: sum(scores) / len(scores) for location, scores in locations.items()} for park, locations in location_scores.items()}

def count_reviews_by_park(data):
    review_counts = {}
    for review in data:
        park = review['Branch']
        review_counts[park] = review_counts.get(park, 0) + 1
    return review_counts

def get_average_scores_by_park(data):
    park_ratings = {}
    for review in data:
        park = review['Branch']
        rating = int(review['Rating'])
        park_ratings.setdefault(park, []).append(rating)
    return {park: sum(ratings) / len(ratings) for park, ratings in park_ratings.items()}

def get_top_locations_by_park(data, park_name):
    location_ratings = {}
    for review in data:
        if review['Branch'] == park_name:
            location = review['Reviewer_Location']
            rating = int(review['Rating'])
            location_ratings.setdefault(location, []).append(rating)
    return sorted(
        {location: sum(ratings) / len(ratings) for location, ratings in location_ratings.items()}.items(),
        key=lambda x: x[1], reverse=True)[:10]

def get_monthly_average_ratings(data, park_name):
    monthly_ratings = {}
    for review in data:
        if review['Branch'] == park_name:
            month = review['Year_Month'][5:7]
            rating = int(review['Rating'])
            monthly_ratings.setdefault(month, []).append(rating)
    return {month: sum(ratings) / len(ratings) for month, ratings in monthly_ratings.items()}

class Exporter:
    def __init__(self, data):
        self.data = data

    def get_aggregate_data(self):
        park_data = {}
        for review in self.data:
            park = review['Branch']
            location = review['Reviewer_Location']
            rating = int(review['Rating'])
            if park not in park_data:
                park_data[park] = {
                    'num_reviews': 0,
                    'positive_reviews': 0,
                    'total_score': 0,
                    'num_locations': set()
                }
            park_data[park]['num_reviews'] += 1
            if rating > 3:
                park_data[park]['positive_reviews'] += 1
            park_data[park]['total_score'] += rating
            park_data[park]['num_locations'].add(location)
        for park, data in park_data.items():
            data['average_score'] = data['total_score'] / data['num_reviews']
            data['num_locations'] = len(data['num_locations'])
        return park_data

    def export_to_txt(self, filename):
        with open(filename, 'w') as file:
            for park, data in self.get_aggregate_data().items():
                file.write(f"{park}:\n")
                for key, value in data.items():
                    file.write(f"  {key}: {value}\n")
                file.write("\n")

    def export_to_csv(self, filename):
        with open(filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Park', 'Number of Reviews', 'Positive Reviews', 'Average Score', 'Number of Locations'])
            for park, data in self.get_aggregate_data().items():
                writer.writerow([park, data['num_reviews'], data['positive_reviews'], data['average_score'], data['num_locations']])

    def export_to_json(self, filename):
        with open(filename, 'w') as file:
            json.dump(self.get_aggregate_data(), file, indent=4)
